<?php $__env->startSection('content'); ?>
	<div class="col-md-8">	
		<div class="card my-5 p-3">
			<h4>Upload Category Here!!</h4>
			<hr>
			
			<form method="POST" action="<?php echo e(route('admin.category.store')); ?>">
				<?php echo csrf_field(); ?>
				<div class="form-group">
					<label>Category name:</label>
					<input type="text" name="name" class="form-control <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>">
					
					<?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?>
    				<div class="alert alert-danger"><?php echo e($message); ?></div>
					<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
				</div>

				
				<div class="form-group">
					<input type="submit" name="btnok" class="btn btn-outline-primary" value="Upload">
					
				</div>
			</form>
			
		</div>
		
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\blog\resources\views/category/create.blade.php ENDPATH**/ ?>