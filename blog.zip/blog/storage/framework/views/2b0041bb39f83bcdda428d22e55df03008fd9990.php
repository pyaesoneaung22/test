<?php $__env->startSection('content'); ?>

	<div class="col-lg-8">

        <!-- Title -->
        <h1 class="mt-4"></h1>

        <!-- Author -->
        <p class="lead">
          by
          <a href="#">Start Bootstrap</a>
        </p>

        <hr>

        <!-- Date/Time -->
        <p>Posted on January 1, 2019 at 12:00 PM</p>
        
        <!-- <a href="#" class="btn btn-primary">Delete</a> -->
        <hr>
         
        <!-- Preview Image -->
        
        
        <hr>
         
        
        <hr>

        <!-- Comments Form -->
        <div class="card my-4">
          <h5 class="card-header">Edit your Comment:</h5>
          <div class="card-body">
            <form method="post" action="<?php echo e(route('comment.update',$comment->id)); ?>">
              <?php echo csrf_field(); ?>
              <?php echo method_field('PUT'); ?>
              <div class="form-group">
                <textarea class="form-control <?php if ($errors->has('comment')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('comment'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="comment" rows="3" >
                  <?php echo e($comment->body); ?>

                </textarea>
                <?php if ($errors->has('comment')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('comment'); ?>
                <div class="alert alert-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>

              </div>
              <div class="form-group">
                <input type="submit" name="btnok" class="btn btn-outline-primary" value="Update">
              </div>
            </form>
          </div>
        </div>

        <!-- Single Comment -->
  </div>
       
      

<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\blog\resources\views/comment/edit.blade.php ENDPATH**/ ?>