<?php $__env->startSection('content'); ?>
	<div class="col-md-8">	
		<div class="card my-5 p-3">
			<h4>Upload Post Here!!</h4>
			<hr>

			<!-- <ul>
				<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

					<li class="text-danger" ><?php echo e($err); ?></li>
					
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</ul> -->

			<form method="POST" action="<?php echo e(route('post.store')); ?>" enctype="multipart/form-data">
				<?php echo csrf_field(); ?>
				<div class="form-group">
					<label>Post title:</label>
					<input type="text" name="title" class="form-control <?php if ($errors->has('title')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('title'); ?> 
					is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>">
					<?php if ($errors->has('title')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('title'); ?>
    				<div class="alert alert-danger"><?php echo e($message); ?></div>
					<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>

				</div>

				<div class="form-group">
					<label>Post Body:</label>
					<textarea name="body" class="form-control <?php if ($errors->has('body')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('body'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>">
					</textarea>
					<?php if ($errors->has('body')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('body'); ?>
    				<div class="alert alert-danger"><?php echo e($message); ?></div>
					<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
					
				</div>

				<div class="form-group">
					<label>Image:</label>
					<input type="file" name="image" class="form-control-file <?php if ($errors->has('image')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('image'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>">
					<?php if ($errors->has('image')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('image'); ?>
    				<div class="alert alert-danger"><?php echo e($message); ?></div>
					<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
					
				</div>

				<div class="form-group">
					<label>Category:</label>
					<select name="category" class="form-control-file <?php if ($errors->has('category')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('category'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>">
						<option value="">Choose Category</option>

						<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

						

					</select>
					<?php if ($errors->has('category')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('category'); ?>
    				<div class="alert alert-danger"><?php echo e($message); ?></div>
					<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
				</div>
				
				<div class="form-group">
					<input type="submit" name="btnok" class="btn btn-outline-primary" value="Upload">
					
				</div>
			</form>
			
		</div>
		
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\blog\resources\views/post/create.blade.php ENDPATH**/ ?>