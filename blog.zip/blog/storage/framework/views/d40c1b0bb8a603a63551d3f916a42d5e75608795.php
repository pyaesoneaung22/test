<?php $__env->startSection('content'); ?>
	<div class="col-lg-8 my-4">
		<div class="card">
			<div class="card-body">
				<form method="post" action="<?php echo e(route('profile.update',$user->id)); ?>" enctype="multipart/form-data">
					<?php echo csrf_field(); ?>
					<?php echo method_field('PUT'); ?>
					<div class="form-group">
						<label>Name</label>
						<input type="text" name="name" class="form-control <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?> 
					is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" value="<?php echo e($user->name); ?>">
					<?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?>
    				<div class="alert alert-danger"><?php echo e($message); ?></div>
					<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
						
					</div>
					<div class="form-group">
						<label>Email</label>
						<input type="email" name="email" class="form-control <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> 
					is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" value="<?php echo e($user->email); ?>" readonly="">
					<?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
    				<div class="alert alert-danger"><?php echo e($message); ?></div>
					<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
						
					</div>
					<div class="form-group">
						<label>New Password:</label>
						<input type="text" name="password" class="form-control <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> 
					is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>">
					<?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>
    				<div class="alert alert-danger"><?php echo e($message); ?></div>
					<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
						
					</div>
					<div class="form-group">
						<img src="<?php echo e(asset($user->avatar)); ?>" class="rounded-circle">
						<input type="hidden" name="oldimg" value="<?php echo e(asset($user->avatar)); ?>">
						
						<input type="file" name="avatar" class="form-control-file <?php if ($errors->has('avatar')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('avatar'); ?> 
						is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>">
						<?php if ($errors->has('avatar')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('avatar'); ?>
    					<div class="alert alert-danger"><?php echo e($message); ?></div>
						<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
					</div>
					<div class="form-group">
						<input type="submit" name="btn" class="btn btn-primary" value="Update">
					</div>
					
				</form>
				
			</div>
			
		</div>
		
	</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\blog\resources\views/profile/edit.blade.php ENDPATH**/ ?>