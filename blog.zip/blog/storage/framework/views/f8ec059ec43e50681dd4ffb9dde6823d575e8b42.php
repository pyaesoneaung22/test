               
    

    <?php $__env->startSection('content'); ?>
      <div class="col-md-8">

        <h1 class="my-4">Page Heading
          <small>Secondary Text</small>
        </h1>

        <!-- Blog Post -->
        
        
            
        <div class="mb-4">
           <a href="<?php echo e(route('admin.category.create')); ?>" class="btn btn-primary btn-round ml-auto float-right">
             Add Row
           </a>
           <div class="table-responsive">
                    <table class="table">
                      <thead>
                        <tr>
                          <th scope="col-lg">No</th>
                          <th scope="col-lg">Name</th>
                          <th scope="col-lg">Action</th>
                        </tr>
                      </thead>
                     
                      <tbody>
                        <?php $i=1; ?>
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        
                        <tr>
                          <td><?php echo e($i++); ?></td>
                          <td><?php echo e($category->name); ?></td>
                          <td>
                            <div class="form-button-action">
                              
                              <a href="<?php echo e(route('admin.category.edit',$category->id)); ?>" data-toggle="tooltip" title="" class="btn btn-outline-primary btn-sm" data-original-title="Edit Task">
                                edit
                              </a>

                               <form method="post" class="d-inline-block" onsubmit="return confirm('Are You Sure?');" action="<?php echo e(route('admin.category.destroy',$category->id)); ?>">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <input type="submit" name="btn" value="Delete" class="btn btn-outline-danger btn-sm">
          
                               </form>
                            </div>
                          </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </tbody>
                    </table>
                  </div>

          <div class="card-footer text-muted">
            Posted on January 1, 2017 by
            <a href="#">Start Bootstrap</a>
          </div>
        </div>
      

       

        <!-- Pagination -->
        <ul class="pagination justify-content-center mb-4">
          <li class="page-item">
            <a class="page-link" href="#">&larr; Older</a>
          </li>
          <li class="page-item disabled">
            <a class="page-link" href="#">Newer &rarr;</a>
          </li>
        </ul>

      </div>

    <?php $__env->stopSection(); ?>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\blog\resources\views/category/index.blade.php ENDPATH**/ ?>