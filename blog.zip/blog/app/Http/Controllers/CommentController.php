<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Comment;
use Illuminate\Support\Facades\DB;
use Auth;

class CommentController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {   // A jax
        //dd($request);

        //Validation
        $request->validate([
            'comment'=>'required|min:10',
            'post_id'=>'required'
        ]);

        // Data Insert
        Comment::create([
            'body'=>request('comment'),
            'post_id'=>request('post_id'),
            'user_id'=>Auth::user()->id
        ]);

        //
        // $post_id=request('post_id');
        // return redirect()->route('post.show',$post_id);

            //OR
       // return redirect()->route('post.show',request('post_id'));

        //OR
        // return back();

         //OR
         //return redirect()->back();

            // A jax
        return response('success');
        
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
         $comment=Comment::find($id);// one line no foreach

        return view('comment.edit',compact('comment'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request)
    {
        //
            // dd($request);

        
            $id=request('comment_id');

            //data Update
            $comment=Comment::find($id);

            $comment->body=request('comment');
           
            $comment->user_id=Auth::user()->id;
        
            $comment->save();
            
            return response('success');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
        //dd($id);
        $comment=Comment::find($id);
        //$post_id=$comment->post_id;

        $comment->delete();

        //redirect
        //return redirect()->route('post.show',$post_id);
        return redirect()->route('post.index',$id);
       //return redirect()->back();
    }

    //for ajax
    public function getcomments(Request $request)
    {   //get id
        // dd($request);

        //accet post_id from ajax request
        $post_id=request('post_id');
       // $comments=Comment::where('post_id',$post_id)->get();
        $comment=DB::table('comments')
                ->join('users','users.id','=','comments.user_id')
                ->where('comments.post_id',$post_id)
                ->orderBy('comments.id','desc')
                ->select('comments.*','users.name','users.avatar')
                ->get();
                
        return response($comment);
    }

}
