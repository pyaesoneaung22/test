<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Auth;

//
use App\Category; //for create
use App\Post;//for store

//Query
use Illuminate\Support\Facades\DB;
class PostController extends Controller
{

    //
    public function __construct($value='')
    {
        $this->middleware('isAuthor',['except'=>['index','show']]);
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {   
        // $posts=Post::all();
        // return view('post.index',compact('posts'));

        // Query form
        $posts=DB::table('posts')
                ->join('users','users.id','=','posts.user_id')
                ->join('categories','categories.id','=','posts.category_id')
                ->select('posts.*','categories.name as cname','users.name as uname')
                ->get();
            //dd($posts);
            return view('post.index',compact('posts'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $categories=Category::all();
        //dd($categories);

        return view('post.create',compact('categories'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
        //dd($request);

        //Validation
        $request->validate([
            "title"=>"required|min:10|max:191",
            "body"=>"required|min:10",
            "image"=>"required|mimes:jpeg,jpg,png|max:5000",
            "category"=>"required"
        ]);

        //If include file, Upload here
            if($request->hasfile('image')){
                $image=$request->file('image');
                $name=$image->getClientOriginalName();
                $image->move(public_path().'/image/',$name);
                $image='/image/'.$name;
            }

        //Save data
            Post::create([
                "title"=>request('title'),
                "body"=>request('body'),
                "image"=>$image,
                "category_id"=>request('category'),
                "user_id"=>Auth::user()->id
            ]);

        //Redirect
            return redirect()->route('post.index');

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
        $post=Post::find($id);
        return view('post.show',compact('post'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
        $post=Post::find($id);// one line no foreach

        $categories=Category::all(); //need loop

        return view('post.edit',compact('post','categories'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
        //dd($request);

        //Validation

            $request->validate([
            "title"=>"required|min:10|max:191",
            "body"=>"required|min:10",
            "image"=>"sometimes|mimes:jpeg,jpg,png|max:5000",
            "category"=>"required"
             ]);
        //File Upload

            if($request->hasfile('image')){
                $image=$request->file('image');
                $name=$image->getClientOriginalName();
                $image->move(public_path().'/image/',$name);
                $image='/image/'.$name;
            }else{
                $image=request('oldimg');
            }


        //Update data

            $post=Post::find($id);
            $post->title=request('title');
            $post->body=request('body');
            $post->image=$image;
            $post->category_id=request('category');
            $post->user_id=Auth::user()->id;
            $post->save();
        //Redirect
            return redirect()->route('post.show',$id);

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
        //dd($id);
        $post=Post::find($id);
        $post->delete();

        //redirect
        return redirect()->route('post.index');
    }
}
