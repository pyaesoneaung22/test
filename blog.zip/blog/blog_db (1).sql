-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 16, 2019 at 04:49 AM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.3.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `blog_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`, `created_at`, `updated_at`) VALUES
(1, 'PC One Shop', '2019-06-24 20:55:22', '2019-06-24 20:55:22');

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `body` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_06_10_070057_create_categories_table', 1),
(4, '2019_06_10_071925_create_posts_table', 1),
(5, '2019_06_10_072448_create_comments_table', 1),
(6, '2016_06_01_000001_create_oauth_auth_codes_table', 2),
(7, '2016_06_01_000002_create_oauth_access_tokens_table', 2),
(8, '2016_06_01_000003_create_oauth_refresh_tokens_table', 2),
(9, '2016_06_01_000004_create_oauth_clients_table', 2),
(10, '2016_06_01_000005_create_oauth_personal_access_clients_table', 2);

-- --------------------------------------------------------

--
-- Table structure for table `oauth_access_tokens`
--

CREATE TABLE `oauth_access_tokens` (
  `id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `client_id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `scopes` text COLLATE utf8mb4_unicode_ci,
  `revoked` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `expires_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `oauth_access_tokens`
--

INSERT INTO `oauth_access_tokens` (`id`, `user_id`, `client_id`, `name`, `scopes`, `revoked`, `created_at`, `updated_at`, `expires_at`) VALUES
('071db98baed24a686746b0adfb77f8c0e17f28b4c565e5283714d0db0e29fdd9761a93881de4298a', 2, 2, NULL, '[]', 0, '2019-06-27 01:08:55', '2019-06-27 01:08:55', '2020-06-27 07:38:55'),
('0fe55509155abf1d93f4080010dae14e285866fb06f38175a2e7d3f6af54a962eb4ab62c6198a5ec', 3, 2, NULL, '[]', 0, '2019-06-27 02:07:14', '2019-06-27 02:07:14', '2020-06-27 08:37:14'),
('24501d82ef5094fc4b57f4d9f82092bda21a7c2349f04976d5e94060372b06ff3058f37bd840405c', 8, 2, NULL, '[]', 0, '2019-06-27 04:16:34', '2019-06-27 04:16:34', '2020-06-27 10:46:34'),
('352fd2f6e979e1f0192cf7087dc45a1e95b8720e66c5fb156b404e72973ef5e26fae281f66f4a326', 9, 2, NULL, '[]', 0, '2019-06-27 04:19:19', '2019-06-27 04:19:19', '2020-06-27 10:49:19'),
('388ea01bc8748ea800d86d4854d1afafb502aebbcb869593562834e1abc941cf5a9626fbe68be2f3', 2, 2, NULL, '[]', 0, '2019-06-27 01:24:02', '2019-06-27 01:24:02', '2020-06-27 07:54:02'),
('40e859d19b453c8367522a69247652072a4e504cfc5e31190a1e2ecbdfa5341558b4c186ecff438d', 5, 2, NULL, '[]', 0, '2019-06-27 04:09:14', '2019-06-27 04:09:14', '2020-06-27 10:39:14'),
('4306a9e8fe7c202256227facafb46f56234ac8287a298182b30dd175c24790be6ebc8df305b155a3', 2, 2, NULL, '[]', 0, '2019-06-27 01:08:57', '2019-06-27 01:08:57', '2020-06-27 07:38:57'),
('4ce1078473cefbdf8dc085fde8bee09c219b12ce161a0f5d117a7d2a080faf06d6d294cc1048386c', 4, 2, NULL, '[]', 0, '2019-06-27 04:06:45', '2019-06-27 04:06:45', '2020-06-27 10:36:45'),
('a877b154e3ea8fc563a5e69ea196e79b33e84251473673b88901105c101c72d6a270ac9dce9949a7', 11, 2, NULL, '[]', 0, '2019-06-27 04:25:46', '2019-06-27 04:25:46', '2020-06-27 10:55:46'),
('a8ba8593c2646fb4743221cd5eb81d9245ed50762ce6581cb10d7785522c3f6c4d99045f5dc3af60', 6, 2, NULL, '[]', 0, '2019-06-27 04:11:33', '2019-06-27 04:11:33', '2020-06-27 10:41:33'),
('ac022b863b7d11086cb2e0ddeea56e73558edba5952c00b6af02305569e9415e3784ecce633a972b', 12, 2, NULL, '[]', 0, '2019-06-27 04:32:37', '2019-06-27 04:32:37', '2020-06-27 11:02:37'),
('ba6702532193372a1a75eccc2c575a85019384356c56581debaa036fa6a641658fe4295a12953872', 2, 2, NULL, '[]', 0, '2019-06-27 01:24:01', '2019-06-27 01:24:01', '2020-06-27 07:54:01'),
('baf2e9ee434ac8bea8770aec8a6fedfcb06764c1b12a659fc727354cc0e3a9efe9d2bd7df487c84b', 2, 2, NULL, '[]', 0, '2019-06-24 23:04:38', '2019-06-24 23:04:38', '2020-06-25 05:34:38'),
('cc7e33703cde7a895d135cac41fd69b27ba963852142c10d20c24884283780f3d5347c487eb61a85', 7, 2, NULL, '[]', 0, '2019-06-27 04:15:19', '2019-06-27 04:15:19', '2020-06-27 10:45:19'),
('d7807ec54cfbcbb3a74ddabd51ea65abd0dfce74300a5aca8b93705f88386ab5af63bf8c78ac811d', 2, 2, NULL, '[]', 0, '2019-06-24 22:33:36', '2019-06-24 22:33:36', '2020-06-25 05:03:36'),
('daf0846de6d9f5322a8ab5f7244b27d4d11c9bc9ddc0f8fa8b63cd61b83494838c39f9102bdb912d', 10, 2, NULL, '[]', 0, '2019-06-27 04:24:03', '2019-06-27 04:24:03', '2020-06-27 10:54:03'),
('f583c6fd065fb10a161da11cc185f3a60551d260a6b43aac0e9de85cb5ed3e3e9ecd85114017d650', 2, 2, NULL, '[]', 0, '2019-06-26 22:54:48', '2019-06-26 22:54:48', '2020-06-27 05:24:48');

-- --------------------------------------------------------

--
-- Table structure for table `oauth_auth_codes`
--

CREATE TABLE `oauth_auth_codes` (
  `id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` int(11) NOT NULL,
  `client_id` int(10) UNSIGNED NOT NULL,
  `scopes` text COLLATE utf8mb4_unicode_ci,
  `revoked` tinyint(1) NOT NULL,
  `expires_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `oauth_clients`
--

CREATE TABLE `oauth_clients` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `secret` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `redirect` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `personal_access_client` tinyint(1) NOT NULL,
  `password_client` tinyint(1) NOT NULL,
  `revoked` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `oauth_clients`
--

INSERT INTO `oauth_clients` (`id`, `user_id`, `name`, `secret`, `redirect`, `personal_access_client`, `password_client`, `revoked`, `created_at`, `updated_at`) VALUES
(1, NULL, 'Laravel Personal Access Client', 'vFTWWcryJLtAAY83IQXkVNFKIrbxca66HuD7xf3C', 'http://localhost', 1, 0, 0, '2019-06-24 22:17:03', '2019-06-24 22:17:03'),
(2, NULL, 'Laravel Password Grant Client', 'efZjWeQ3JEwJzaW8jCFE4YAHZXg4FDgpxfCvfyZz', 'http://localhost', 0, 1, 0, '2019-06-24 22:17:03', '2019-06-24 22:17:03');

-- --------------------------------------------------------

--
-- Table structure for table `oauth_personal_access_clients`
--

CREATE TABLE `oauth_personal_access_clients` (
  `id` int(10) UNSIGNED NOT NULL,
  `client_id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `oauth_personal_access_clients`
--

INSERT INTO `oauth_personal_access_clients` (`id`, `client_id`, `created_at`, `updated_at`) VALUES
(1, 1, '2019-06-24 22:17:03', '2019-06-24 22:17:03');

-- --------------------------------------------------------

--
-- Table structure for table `oauth_refresh_tokens`
--

CREATE TABLE `oauth_refresh_tokens` (
  `id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `access_token_id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `revoked` tinyint(1) NOT NULL,
  `expires_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `oauth_refresh_tokens`
--

INSERT INTO `oauth_refresh_tokens` (`id`, `access_token_id`, `revoked`, `expires_at`) VALUES
('0746f32ad0ade35ab69e352c2f891e02120838364deb552151eda7f7a959d5510292018134fbe6cd', 'ac022b863b7d11086cb2e0ddeea56e73558edba5952c00b6af02305569e9415e3784ecce633a972b', 0, '2020-06-27 11:02:37'),
('49a28b164e61eb7132f53a51b9ecaaf317489f1704695ddc60c080d6a81d52dc1c7eafd14a546270', '352fd2f6e979e1f0192cf7087dc45a1e95b8720e66c5fb156b404e72973ef5e26fae281f66f4a326', 0, '2020-06-27 10:49:19'),
('5c39ec523f0e78d0dcb005729c703b1d771ecfec4f347612f3691a8dfcac95474be2fb643c692dfd', 'a8ba8593c2646fb4743221cd5eb81d9245ed50762ce6581cb10d7785522c3f6c4d99045f5dc3af60', 0, '2020-06-27 10:41:33'),
('6e9db50e70211ae3ad9b44792bc4e3e8b11642015dcbe66378ac1a30a9916a1064c10e4d623c3d7f', '24501d82ef5094fc4b57f4d9f82092bda21a7c2349f04976d5e94060372b06ff3058f37bd840405c', 0, '2020-06-27 10:46:34'),
('6fdda488f8f448cef08eab8aee514b1ce5c9d5fa2053dde146169e8d148d4389bdb526aa4702c8b8', '071db98baed24a686746b0adfb77f8c0e17f28b4c565e5283714d0db0e29fdd9761a93881de4298a', 0, '2020-06-27 07:38:55'),
('814997e84ced660d3becc9cd68bf0a363f0a47f01eaaa3a535d25a6c1dcdb8198f6e4525599e18e0', 'f583c6fd065fb10a161da11cc185f3a60551d260a6b43aac0e9de85cb5ed3e3e9ecd85114017d650', 0, '2020-06-27 05:24:48'),
('821a7bb054476d5704c010f1435edeec5a36e7afcb73afd2b30f6681503da86855fb58b7bc323002', 'daf0846de6d9f5322a8ab5f7244b27d4d11c9bc9ddc0f8fa8b63cd61b83494838c39f9102bdb912d', 0, '2020-06-27 10:54:03'),
('8364b8074b9f08cd116bfd0d609773a96a31b91f0d3a38d09f9e41cd0c212d8fbb1a7ab5c75553cc', 'a877b154e3ea8fc563a5e69ea196e79b33e84251473673b88901105c101c72d6a270ac9dce9949a7', 0, '2020-06-27 10:55:46'),
('9456e80b7d9db4452aa0227963fd36c4a8968c6467995ec6006beae7f8e1eaa20c23de22032d02f5', 'ba6702532193372a1a75eccc2c575a85019384356c56581debaa036fa6a641658fe4295a12953872', 0, '2020-06-27 07:54:01'),
('a6781ce6775f62900fac07191a563b386e63ac7ac03fcff01ec4db0a642cc619e7c232b89e14464b', '4306a9e8fe7c202256227facafb46f56234ac8287a298182b30dd175c24790be6ebc8df305b155a3', 0, '2020-06-27 07:38:57'),
('a8a50eb3de6673243c2c82a28c78f5efce1deab53647f965dbd0a5c2509e0f9def4ca69670102040', '0fe55509155abf1d93f4080010dae14e285866fb06f38175a2e7d3f6af54a962eb4ab62c6198a5ec', 0, '2020-06-27 08:37:14'),
('b61068018361a545e4625ed76804d8f9112c58082483528cfed54a98729056e6c9bb8c4f54030da3', 'd7807ec54cfbcbb3a74ddabd51ea65abd0dfce74300a5aca8b93705f88386ab5af63bf8c78ac811d', 0, '2020-06-25 05:03:36'),
('bf9aaef6f9b44c032e16a75b15fa96bfc25882f7f4938c5cfa8be52d404c34c32f50b2e43c66d635', 'cc7e33703cde7a895d135cac41fd69b27ba963852142c10d20c24884283780f3d5347c487eb61a85', 0, '2020-06-27 10:45:19'),
('cfd9c347007b7f4702c6ab99a608dcc332715ac35693a2e7d332f30f27550d690580e688b03aa25e', '4ce1078473cefbdf8dc085fde8bee09c219b12ce161a0f5d117a7d2a080faf06d6d294cc1048386c', 0, '2020-06-27 10:36:45'),
('d0ba6462ee54aa2856b8ccc452eb75a80e725a82e240d052e12b87c4aac70ab15299e05b57de37f4', '40e859d19b453c8367522a69247652072a4e504cfc5e31190a1e2ecbdfa5341558b4c186ecff438d', 0, '2020-06-27 10:39:14'),
('ddc95d2c05ecef40c81f71e51c1a916b4b47c71cdb29e024003e8e71aad2c53733b014b7c938e488', '388ea01bc8748ea800d86d4854d1afafb502aebbcb869593562834e1abc941cf5a9626fbe68be2f3', 0, '2020-06-27 07:54:03'),
('ffbd44e3b22b7f0051c1f53f0fd07f13eca337773d280683967721a8cd16af39d24baa0a62c373e3', 'baf2e9ee434ac8bea8770aec8a6fedfcb06764c1b12a659fc727354cc0e3a9efe9d2bd7df487c84b', 0, '2020-06-25 05:34:38');

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE `posts` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `body` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `category_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`id`, `title`, `body`, `image`, `category_id`, `user_id`, `created_at`, `updated_at`) VALUES
(1, 'Dar Taung kyaw', 'hi you are', '/image/2.jpg', 1, 2, '2019-06-24 20:56:19', '2019-06-24 21:24:16'),
(2, 'SecondPost', 'Hi good Quality', '/image/3.jpg', 1, 2, '2019-06-24 21:19:26', '2019-06-24 21:19:26'),
(3, 'This is title 3  update', 'This is update body', '/image/0.jpg', 1, 2, '2019-06-24 21:48:39', '2019-06-25 00:53:45'),
(6, 'This is Title', 'This is body from Post Man', '/image/1.jpg', 1, 1, '2019-06-24 23:55:44', '2019-06-24 23:55:44'),
(7, 'This is Title', 'This is body from Post Man', '/image/1.jpg', 1, 2, '2019-06-25 00:14:40', '2019-06-25 00:14:40'),
(8, 'This is Title', 'This is body from Post Man', '/image/1.jpg', 1, 2, '2019-06-25 00:15:25', '2019-06-25 00:15:25'),
(9, 'This is Title for api auth', 'This is body from Post Man', '/image/1.jpg', 1, 2, '2019-06-25 00:17:00', '2019-06-25 00:17:00');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `avatar` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'defaultavatar.jpg',
  `role` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'author',
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `avatar`, `role`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Admin', 'pyaesone@gmail.com', NULL, '$2y$10$wFG0/k9tQYTsTR5kGCj2z.qqs47NR/VE1FURpP7vm/YbIBHrhi6UK', 'defaultavatar.jpg', 'admin', NULL, '2019-06-24 20:53:46', '2019-06-24 20:53:46'),
(2, 'Pyae Phyo', 'pyaephyo@gmail.com', NULL, '$2y$10$9CaTL6i4ChjogPHKH0Cpju4evOfgpeJBOH91BQAmh6KOaDm7GQKPm', 'defaultavatar.jpg', 'author', NULL, '2019-06-24 20:55:52', '2019-06-24 20:55:52'),
(3, 'Test Testing', 'test@gmail.com', NULL, '$2y$10$JY/rduKeFF4Wwkv/Pnp8h.ME6YGMtubYSV.f789o75/lDsHlcWV3K', 'defaultavatar.jpg', 'author', NULL, '2019-06-27 02:07:14', '2019-06-27 02:07:14');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `oauth_access_tokens`
--
ALTER TABLE `oauth_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD KEY `oauth_access_tokens_user_id_index` (`user_id`);

--
-- Indexes for table `oauth_auth_codes`
--
ALTER TABLE `oauth_auth_codes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `oauth_clients`
--
ALTER TABLE `oauth_clients`
  ADD PRIMARY KEY (`id`),
  ADD KEY `oauth_clients_user_id_index` (`user_id`);

--
-- Indexes for table `oauth_personal_access_clients`
--
ALTER TABLE `oauth_personal_access_clients`
  ADD PRIMARY KEY (`id`),
  ADD KEY `oauth_personal_access_clients_client_id_index` (`client_id`);

--
-- Indexes for table `oauth_refresh_tokens`
--
ALTER TABLE `oauth_refresh_tokens`
  ADD PRIMARY KEY (`id`),
  ADD KEY `oauth_refresh_tokens_access_token_id_index` (`access_token_id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `oauth_clients`
--
ALTER TABLE `oauth_clients`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `oauth_personal_access_clients`
--
ALTER TABLE `oauth_personal_access_clients`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
