@extends('template')
@section('content')

	<div class="col-lg-8">

        <!-- Title -->
        <h1 class="mt-4">{{$post->title}}</h1>

        <!-- Author -->
        <p class="lead">
          by
          <a href="#">{{$post->user->name}}</a>
        </p>

        <hr>

        <!-- Date/Time -->
        <p>hhh</p>

        <!-- To Edit Auth -->
        @if(Auth::check() && Auth::user()->id == $post->user_id)
        <a href="{{route('post.edit',$post->id)}}" class="btn btn-warning">Edit</a>

        <form method="post" class="d-inline-block" onsubmit="return confirm('Are You Sure?');" action="{{route('post.destroy',$post->id)}}">
          @csrf
          @method('DELETE')
          <input type="submit" name="btn" value="Delete" class="btn btn-danger">
          
        </form>
        @endif
        <!-- To Edit Auth End -->
        <!-- <a href="#" class="btn btn-primary">Delete</a> -->
        <hr>
         
        <!-- Preview Image -->
        <img class="img-fluid rounded" src="{{asset($post->image)}}" alt="">
        
        <hr>
          <p>{{$post->body}}</p>
        
        <hr>

        <!-- Comments Form -->
        <div class="card my-4">
          <h5 class="card-header">Leave a Comment:</h5>
          <div class="card-body">
            <form method="post" action="{{route('comment.store')}}">
              @csrf
              <input type="hidden" name="post_id" value="{{$post->id}}">

              <div class="form-group">
                <textarea class="form-control @error('comment') is-invalid @enderror" name="comment" rows="3" ></textarea>
                @error('comment')
                <div class="alert alert-danger">{{ $message }}</div>
                @enderror

              </div>
              <button type="submit" class="btn btn-primary">Submit</button>
            </form>
          </div>
        </div>

        <!-- Single Comment -->
        @foreach($post->comments as $comment)
        <div class="media mb-4">
          <img class="d-flex mr-3 rounded-circle" width="30" src="{{asset($comment->user->avatar)}}" alt="...">
          <div class="media-body">
            <h5 class="mt-0">{{$comment->user->name}}</h5>
            <span class="float-right small">
              {{$comment->created_at->diffForHumans()}}
            </span>
            {{$comment->body}}
          </div>
        
            <a href="{{route('comment.edit',$comment->id)}}" class="btn btn-outline-primary btn-sm">Edit</a>

        <form method="post" class="d-inline-block" onsubmit="return confirm('Are You Sure?');" action="            {{route('comment.destroy',$comment->id)}}">
          @csrf
          @method('DELETE')
          <input type="submit" name="btn" value="Delete" class="btn btn-outline-danger btn-sm">
          
        </form>
        
         
        </div>
        @endforeach
        <!-- Comment with nested comments -->
  </div>

@endsection

@section('script')

  <script type="text/javascript">
    $(document).ready(function(){
      alert('Ok');
    })
  </script>
@endsection