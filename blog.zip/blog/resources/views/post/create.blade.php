@extends('template')
@section('content')
	<div class="col-md-8">	
		<div class="card my-5 p-3">
			<h4>Upload Post Here!!</h4>
			<hr>

			<!-- <ul>
				@foreach($errors->all() as $err)

					<li class="text-danger" >{{$err}}</li>
					
				@endforeach
			</ul> -->

			<form method="POST" action="{{route('post.store')}}" enctype="multipart/form-data">
				@csrf
				<div class="form-group">
					<label>Post title:</label>
					<input type="text" name="title" class="form-control @error('title') 
					is-invalid @enderror">
					@error('title')
    				<div class="alert alert-danger">{{ $message }}</div>
					@enderror

				</div>

				<div class="form-group">
					<label>Post Body:</label>
					<textarea name="body" class="form-control @error('body') is-invalid @enderror">
					</textarea>
					@error('body')
    				<div class="alert alert-danger">{{ $message }}</div>
					@enderror
					
				</div>

				<div class="form-group">
					<label>Image:</label>
					<input type="file" name="image" class="form-control-file @error('image') is-invalid @enderror">
					@error('image')
    				<div class="alert alert-danger">{{ $message }}</div>
					@enderror
					
				</div>

				<div class="form-group">
					<label>Category:</label>
					<select name="category" class="form-control-file @error('category') is-invalid @enderror">
						<option value="">Choose Category</option>

						@foreach($categories as $category)
						<option value="{{$category->id}}">{{$category->name}}</option>
						@endforeach

						

					</select>
					@error('category')
    				<div class="alert alert-danger">{{ $message }}</div>
					@enderror
				</div>
				
				<div class="form-group">
					<input type="submit" name="btnok" class="btn btn-outline-primary" value="Upload">
					
				</div>
			</form>
			
		</div>
		
	</div>
@endsection