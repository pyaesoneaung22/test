@extends('template')
@section('content')

	<div class="col-lg-8">

        <!-- Title -->
        <h1 class="mt-4">{{$post->title}}</h1>

        <!-- Author -->
        <p class="lead">
          by
          <a href="#">{{$post->user->name}}</a>
        </p>

        <hr>

        <!-- Date/Time -->
        <p>{{$post->user->created_at}}</p>

        <!-- To Edit Auth -->
        @if(Auth::check() && Auth::user()->id == $post->user_id)
        <a href="{{route('post.edit',$post->id)}}" class="btn btn-warning">Edit</a>

        <form method="post" class="d-inline-block" onsubmit="return confirm('Are You Sure?');" action="{{route('post.destroy',$post->id)}}">
          @csrf
          @method('DELETE')
          <input type="submit" name="btn" value="Delete" class="btn btn-danger">
          
        </form>
        @endif
        <!-- To Edit Auth End -->
        <!-- <a href="#" class="btn btn-primary">Delete</a> -->
        <hr>
         
        <!-- Preview Image -->
        <img class="img-fluid rounded" src="{{asset($post->image)}}" alt="">
        
        <hr>
          <p>{{$post->body}}</p>
        
        <hr>

        <!-- Comments Form -->
        <div class="card my-4">
          <h5 class="card-header">Leave a Comment:</h5>
          <div class="card-body">
              @csrf
              <input type="hidden" name="post_id" id="post_id" value="{{$post->id}}">

              <div class="form-group">
                <textarea class="form-control @error('comment') is-invalid @enderror" name="comment" id="comment" rows="3" >
                </textarea>
                @error('comment')
                <div class="alert alert-danger">{{ $message }}</div>
                @enderror

              </div>
              <button type="submit" class="btn btn-primary submit">Submit</button>
         
          </div>
        </div>

        <!-- Single Comment -->
       <div id="showcomment">
         
       </div>



       
  </div>

@endsection

@section('script')

  <script type="text/javascript">
    $(document).ready(function(){

      //ajax setup here
        $.ajaxSetup({
        headers: {
         'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
      });


      var post_id=$('#post_id').val();
      getComments(post_id);
      // alert('Ok');
      $('.submit').click(function(){

        // var post_id=$('#post_id').val();
        var comment=$('#comment').val();
        // alert(post_id+comment);

        $.post('/comment',{post_id:post_id,comment:comment},function(response){
          console.log(response);
          $('#comment').val('');
          getComments(post_id);
        })

      })

//for edit
      $('#showcomment').on('click','.edit',function(e)
      {
        e.preventDefault();
        $(this).parents('.comment').find('.editform').removeClass('d-none');
      });

      $('#showcomment').on('click','.update',function(argument){
        var commenttxt=$(this).parents('.comment').find('.commenttxt').val();

        var post_id=$(this).parents('.comment').find('.postid').val();

        var comment_id=$(this).parents('.comment').find('.commentid').val();

        alert(commenttxt+post_id+comment_id);
          //for update
          $.post("{{route('comment_update')}}",{post_id:post_id,comment:commenttxt,comment_id:comment_id},function(response){
            console.log(response);
            getComments(post_id);

          })
        

      })


     function getComments(post_id){
        $.post("{{route('getcomments')}}",{post_id:post_id},function(response){
          console.log(response);

          var html='';
          $.each(response,function(i,v)
          {

            var avatar=v.avatar;
            var name=v.name;
            var comment=v.body;
            var id=v.id;
            html+='<div class="comment"><img src="'+avatar+'" width="50">'+
                  '<p>'+name+'</p>'+
                  '<p>'+comment+'</p>'+
                  '<div class="d-none editform"><input type="text" value="'+comment+'" class="commenttxt form-control">'+
                  '<input type="text" value="'+post_id+'" class="form-control postid">'+
                  '<input type="text" value="'+id+'" class="form-control commentid">'+
                  '<button class="update btn btn-info btn-sm">update</button>'+
                  '</div>'+
                  '<a href="#" class="edit btn btn-warning btn-sm">edit</a>'+
                  '</div>';

          })
          $('#showcomment').html(html);
        })
     }

    })
  </script>
@endsection