<!DOCTYPE html>
<html>
<head>
	<title>Testing Page</title>
</head>
<body>
	<h2>This is a testing view.</h2>
</body>
</html>