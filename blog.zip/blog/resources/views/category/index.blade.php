               
    @extends('template')

    @section('content')
      <div class="col-md-8">

        <h1 class="my-4">Page Heading
          <small>Secondary Text</small>
        </h1>

        <!-- Blog Post -->
        
        
            
        <div class="mb-4">
           <a href="{{route('admin.category.create')}}" class="btn btn-primary btn-round ml-auto float-right">
             Add Row
           </a>
           <div class="table-responsive">
                    <table class="table">
                      <thead>
                        <tr>
                          <th scope="col-lg">No</th>
                          <th scope="col-lg">Name</th>
                          <th scope="col-lg">Action</th>
                        </tr>
                      </thead>
                     
                      <tbody>
                        <?php $i=1; ?>
                        @foreach($categories as $category)
                        
                        <tr>
                          <td>{{$i++}}</td>
                          <td>{{$category->name}}</td>
                          <td>
                            <div class="form-button-action">
                              
                              <a href="{{route('admin.category.edit',$category->id)}}" data-toggle="tooltip" title="" class="btn btn-outline-primary btn-sm" data-original-title="Edit Task">
                                edit
                              </a>

                               <form method="post" class="d-inline-block" onsubmit="return confirm('Are You Sure?');" action="{{route('admin.category.destroy',$category->id)}}">
                                @csrf
                                @method('DELETE')
                                <input type="submit" name="btn" value="Delete" class="btn btn-outline-danger btn-sm">
          
                               </form>
                            </div>
                          </td>
                        </tr>
                        @endforeach
                      </tbody>
                    </table>
                  </div>

          <div class="card-footer text-muted">
            Posted on January 1, 2017 by
            <a href="#">Start Bootstrap</a>
          </div>
        </div>
      

       

        <!-- Pagination -->
        <ul class="pagination justify-content-center mb-4">
          <li class="page-item">
            <a class="page-link" href="#">&larr; Older</a>
          </li>
          <li class="page-item disabled">
            <a class="page-link" href="#">Newer &rarr;</a>
          </li>
        </ul>

      </div>

    @endsection
