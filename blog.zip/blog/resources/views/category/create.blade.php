@extends('template')
@section('content')
	<div class="col-md-8">	
		<div class="card my-5 p-3">
			<h4>Upload Category Here!!</h4>
			<hr>
			
			<form method="POST" action="{{route('admin.category.store')}}">
				@csrf
				<div class="form-group">
					<label>Category name:</label>
					<input type="text" name="name" class="form-control @error('name') is-invalid @enderror">
					
					@error('name')
    				<div class="alert alert-danger">{{ $message }}</div>
					@enderror
				</div>

				
				<div class="form-group">
					<input type="submit" name="btnok" class="btn btn-outline-primary" value="Upload">
					
				</div>
			</form>
			
		</div>
		
	</div>
@endsection