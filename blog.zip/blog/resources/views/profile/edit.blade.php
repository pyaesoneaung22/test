@extends('template')

@section('content')
	<div class="col-lg-8 my-4">
		<div class="card">
			<div class="card-body">
				<form method="post" action="{{route('profile.update',$user->id)}}" enctype="multipart/form-data">
					@csrf
					@method('PUT')
					<div class="form-group">
						<label>Name</label>
						<input type="text" name="name" class="form-control @error('name') 
					is-invalid @enderror" value="{{$user->name}}">
					@error('name')
    				<div class="alert alert-danger">{{ $message }}</div>
					@enderror
						
					</div>
					<div class="form-group">
						<label>Email</label>
						<input type="email" name="email" class="form-control @error('email') 
					is-invalid @enderror" value="{{$user->email}}" readonly="">
					@error('email')
    				<div class="alert alert-danger">{{ $message }}</div>
					@enderror
						
					</div>
					<div class="form-group">
						<label>New Password:</label>
						<input type="text" name="password" class="form-control @error('password') 
					is-invalid @enderror">
					@error('password')
    				<div class="alert alert-danger">{{ $message }}</div>
					@enderror
						
					</div>
					<div class="form-group">
						<img src="{{asset($user->avatar)}}" class="rounded-circle">
						<input type="hidden" name="oldimg" value="{{asset($user->avatar)}}">
						
						<input type="file" name="avatar" class="form-control-file @error('avatar') 
						is-invalid @enderror">
						@error('avatar')
    					<div class="alert alert-danger">{{ $message }}</div>
						@enderror
					</div>
					<div class="form-group">
						<input type="submit" name="btn" class="btn btn-primary" value="Update">
					</div>
					
				</form>
				
			</div>
			
		</div>
		
	</div>

@endsection