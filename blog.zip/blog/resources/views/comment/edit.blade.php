@extends('template')
@section('content')

	<div class="col-lg-8">

        <!-- Title -->
        <h1 class="mt-4"></h1>

        <!-- Author -->
        <p class="lead">
          by
          <a href="#">Start Bootstrap</a>
        </p>

        <hr>

        <!-- Date/Time -->
        <p>Posted on January 1, 2019 at 12:00 PM</p>
        
        <!-- <a href="#" class="btn btn-primary">Delete</a> -->
        <hr>
         
        <!-- Preview Image -->
        
        
        <hr>
         
        
        <hr>

        <!-- Comments Form -->
        <div class="card my-4">
          <h5 class="card-header">Edit your Comment:</h5>
          <div class="card-body">
            <form method="post" action="{{route('comment.update',$comment->id)}}">
              @csrf
              @method('PUT')
              <div class="form-group">
                <textarea class="form-control @error('comment') is-invalid @enderror" name="comment" rows="3" >
                  {{$comment->body}}
                </textarea>
                @error('comment')
                <div class="alert alert-danger">{{ $message }}</div>
                @enderror

              </div>
              <div class="form-group">
                <input type="submit" name="btnok" class="btn btn-outline-primary" value="Update">
              </div>
            </form>
          </div>
        </div>

        <!-- Single Comment -->
  </div>
       
      

@endsection